## Category

Discrete
**Diodes & Rectifier**

KEC has a wide variety of diode portfolios available for use in various fields and applications. The portfolio has been trusted by the customers for a long time and includes stable items such as protection diode, switching diode, zener diode, shottky barrier diode, fast recovery rectifier among others, as well as product lineups with AEC-Q101 certificates, available for use in automobiles.

![카테고리 들어갑니다.](https://www.keccorp.com/data/catedata/main_product_test_img_03.png)

**Switching Diode**
[Learn more](https://www.keccorp.com/en/product/product_list.asp?part_idx=14)

A general purpose switching diode for rectification and switching. KEC's switching diodes offer high reliability and are provided in various packages to be used in various applications. KEC provides switching diode lineups with the AEC-Q101 certification.

**Zener Diode**
[Learn more](https://www.keccorp.com/en/product/product_list.asp?part_idx=15)

Zener diode to be used for static voltage circuits. KEC's Zener diodes are highly reliable and are provided in various packages with the AEC-Q101 certification.

**Schottky Barrier Diode**
[Learn more](https://www.keccorp.com/en/product/product_list.asp?part_idx=13)

Diodes using schottky barriers occurring from joining metals and semiconductors. KEC offers various schottky barrier diode portfolio packages based on 2 structures from Planar and Trench products.

**Protection Diode**
[Learn more](https://www.keccorp.com/en/product/product_list.asp?part_idx=12)

Effective for protection of various ICs and systems through low capacitance and high ESD content. KEC offers various protection diode product lineups for each package and broad operation voltage ranges, as well as products with the AEC-Q101 certification.

**Bridge Diode**
[Learn more](https://www.keccorp.com/en/product/product_list.asp?part_idx=38)

KEC's Bridge Diodes has a portfolio consisting of a broad spectrum of voltage specifications and various SMD and THD type packages. As KEC's Bridge Diode is available for various applications, it is possible to recommend products suitable for customers.

**Rectifier**
[Learn more](https://www.keccorp.com/en/product/product_list.asp?part_idx=10)

KEC offers a range of "GP Rectifier" and Fast Recovery Rectifier products suitable for general-purpose and high-speed switching. Available in various package configurations, they can be applied to SMPS Solutions.

**SiC Schottky Diodes**
[Learn more](https://www.keccorp.com/en/product/product_list.asp?part_idx=36)

KEC's SiC (Silicon Carbide) Shottky Barrier Diode is the next-generation power semiconductor that displays excellent performance without reverse recovery current and switching loss. KEC has a wide range of portfolios from 650V to 1200V, providing SiC SBDs suitable for various applications such as UPS, Solar Inverter, and EV Charging


