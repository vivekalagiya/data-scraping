Gate Drivers
**KIB2040QN33**

Automotive QualifiedNew

Three Phase MOSFET Gate Driver, QFN-28, 3.3V

[![KIB2040QN33](https://www.keccorp.com/kr/product/image_sfile.asp?idx=4222)](https://www.keccorp.com/kr/product/image_sfile.asp?idx=4222)

[Download Datasheet](https://www.keccorp.com/kr/product/image_product.asp?gu=1&idx=4222)
[Request Sample](https://www.keccorp.com/en/company/contact.asp?pidx=4222&anchor=contactCon)

**Application**

· Lawn and garden equipment
· Battery-operated power tools

**Features**

· High-current 3-phase gate drive for N-channel MOSFETs
· 5.5 to 38 V supply voltage range
· Internal LDO Regulator (3.3V)
· Internal charge pump Regulator
· Motor phase short-to-supply and short-to-ground detection
· Undervoltage, Overtemperature monitors
· Suffix U : Qualified to AEC-Q100 Grade 1

|  |  |
| --- | --- |
| Item No | KIB2040QN33 |
| Package | QFN-28 |

#### Related Solution

* [![](https://www.keccorp.com/data/catedata/KMD2040.PNG)

**BLDC Motor Drive Board - KIB2040EVB30W**](https://www.keccorp.com/en/application/application_view.asp?part_idx=168)

#### Product Datasheet

* [Product Datasheet] KIB2040QN33\_50.pdf

377.4 KBPDF

[Download](https://www.keccorp.com/kr/product/image_product.asp?gu=1&idx=4222)
* [Package Dimension] QFN-28 PKG.pdf

218 KBPDF

Download
* [Packing Information] QFN-28 Packing.pdf

524.6 KBPDF

Download
* [Recommended Pad Dimension] QFN-28 RPD.pdf

50.2 KBPDF

Download

#### Ordering Information

| Part number | Status | Compliance | | | Package | Packing Type | Packing Q’ty[pcs] | RoHS | REACH | Samples |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| AEC-Q | Pb-Free | Halogen Free |
| KIB2040QN33-EL/HU | New | Yes | Yes | Yes | QFN-28 | Taping | 5,000 | Yes | Yes | [Request Sample](https://www.keccorp.com/en/company/contact.asp?pidx=4222&anchor=contactCon) |

**\* EU RoHS Exemption Usage**
A few of KEC products are RoHS-compliant with the use of an EU RoHS exemption for lead, specifically.
For the latest information regarding applicable RoHS exemptions and their expiration dates, please contact the Quality Team.


