20 Watt, 1/8" Pencil-Style Soldering Iron



##### Added to Cart

×

![](https://americanbeautytools.com/images//nav/ajax-loader.gif)

Continue Shopping
[Checkout](https://americanbeautytools.com/viewcart)

[Home](https://americanbeautytools.com/) / [Pencil Irons](https://americanbeautytools.com/pencil-irons) / [20 Watt & Up Pencil-Style Irons](https://americanbeautytools.com/soldering-iron-3108)

Model # 3108-20

#### 20 Watt, 1/8" Pencil-Style Soldering Iron

![3108-20](https://americanbeautytools.com/images/product_images/3108_6252019024304.jpg)

Testimonials

> My company specializes in supplying and installing high-end custom copper gutter-work, and I've been using American Beauty's [300](https://www.americanbeautytools.com/images/charlie-3a.jpg) & [550 watt](https://www.americanbeautytools.com/images/charlie-4a.jpg) heavy-duty soldering irons for years. It is absolutely essential that these joints are done properly the first time, as repairs will prove 100 times more difficult than simply doing the job correctly the first time. I can always count on my American Beauty iron to generate and maintain enough heat to ensure perfectly soldered seams.
>
> [Charlie @ Chuck-Ways Contracting Co., Shelby Township, MI](https://www.americanbeautytools.com/index.php?req=sheet&app=1)

> Your soldering irons are the best. I've used my old trusty, rusty's for about 40 years, since I bought them all at Chicago's historic Maxwell street market for about 5 bucks as a young, broke artist. They sure have served me well all these years..soldering many a [lamp](http://www.opalglassstudio.com/lighting.html) and [window](http://www.opalglassstudio.com/commercial.html)!
>
> I also think its great you encourage [repair of tools](https://www.americanbeautytools.com/repair) in this sadly throw away world. Thanks for your doing your part of keeping less of landfills.
>
> Sharon B. @ [Opal Glass Studio](http://www.opalglassstudio.com/) in Chicago, IL

|  |  |
| --- | --- |
| $79.99 | QTY.   [add to cart    ADD TO CART](#) |

Product Overview

The little guy that really packs a punch! Designed in the same fashion as our heavy-duty soldering irons, these pencil-style irons are certainly not your average hobby iron. Referred to as production-ready, these irons repeatedly perform hard soldering applications, day in and day out. The combination of intense heat and unmatched durability yields a pencil iron that can proudly be called an American Beauty and makes a versatile tool in any maintenance and repair operation. (*Stand Included*)

  
  

FEATURES AND BENEFITS

  

**Ni-Chrome Compression Wound Heating Elements** are proven to be the most reliable heating element for maintaining soldering temperature in production environments.  
  
**Paragon Iron-Clad Lead-Free Soldering Iron Tips** Will consistently outperform and outlast ordinary soldering iron tips many times over. **Plug-style tip design** provides for superior heat transfer and easy cleaning.  
  
**Molded Nylon contoured handle** provides excellent thermal and electrical insulating properties, for durability, comfort and balance.  
  
**Modular construction** allows for easy replacement of consumable parts allowing for tools to last for generations.

  
  

REPLACEMENT PARTS

  

The following products can be used as replacements for Model 3108-20 featured on this page:  
  

| Model | Product Name | Price |  |
| --- | --- | --- | --- |
| [3916](/Soldering-Irons/39) | [Replacement Handle/Cord set for Pencil Irons](/Soldering-Irons/39) | [$29.99](/Soldering-Irons/39) | [Add to Cart](https://americanbeautytools.com/viewcart/3916/1) |
| [3936](/Soldering-Irons/9758) | [Replacement Item\_Set Screws](/Soldering-Irons/9758) | [$14.99](/Soldering-Irons/9758) | [Add to Cart](https://americanbeautytools.com/viewcart/3936/1) |
| [501](/soldering-tips-500/42) | [Chisel Style Soldering Tip](/soldering-tips-500/42) | [$14.50](/soldering-tips-500/42) | [Add to Cart](https://americanbeautytools.com/viewcart/501/1) |
| [571](/Soldering-Irons/237) | [Soldering Iron Stand](/Soldering-Irons/237) | [$10.99](/Soldering-Irons/237) | [Add to Cart](https://americanbeautytools.com/viewcart/571/1) |
| [9014-20](/Soldering-Irons/20) | [Replacement 20 Watt Compression-Wound Heating Element](/Soldering-Irons/20) | [$55.99](/Soldering-Irons/20) | [Add to Cart](https://americanbeautytools.com/viewcart/9014-20/1) |

  
  

ACCESSORIES

  

The following products can be used as Accessories for Model 3108-20 featured on this page:  
  

| Model | Product Name | Price |  |
| --- | --- | --- | --- |
| [480](/Cleaning-Maintenance/212) | ['One-Pass' Solder Tip Cleaner](/Cleaning-Maintenance/212) | [$20.99](/Cleaning-Maintenance/212) | [Add to Cart](https://americanbeautytools.com/viewcart/480/1) |
| [484-2G](/Desoldering-Braid/9250) | [Dri-Wick Desoldering Braid (Size Two~Spool)](/Desoldering-Braid/9250) | [$5.24](/Desoldering-Braid/9250) | [Add to Cart](https://americanbeautytools.com/viewcart/484-2G/1) |
| [505](/soldering-tips-500/44) | [Diamond Style Soldering Tip](/soldering-tips-500/44) | [$14.50](/soldering-tips-500/44) | [Add to Cart](https://americanbeautytools.com/viewcart/505/1) |
| [507](/soldering-tips-500/45) | [Screwdriver Style Soldering Tip](/soldering-tips-500/45) | [$14.50](/soldering-tips-500/45) | [Add to Cart](https://americanbeautytools.com/viewcart/507/1) |
| [510](/soldering-tips-500/46) | [Conical Style Soldering Tip](/soldering-tips-500/46) | [$14.50](/soldering-tips-500/46) | [Add to Cart](https://americanbeautytools.com/viewcart/510/1) |
| [CS-FX1](/Flux/243) | [Flux Pen](/Flux/243) | [$24.99](/Flux/243) | [Add to Cart](https://americanbeautytools.com/viewcart/CS-FX1/1) |
| [CS-PBF1](/Solder/246) | [Solder Tube](/Solder/246) | [$14.99](/Solder/246) | [Add to Cart](https://americanbeautytools.com/viewcart/CS-PBF1/1) |
| [CS-TT1](/Cleaning-Maintenance/247) | [Tip Tinner](/Cleaning-Maintenance/247) | [$23.99](/Cleaning-Maintenance/247) | [Add to Cart](https://americanbeautytools.com/viewcart/CS-TT1/1) |
| [HS-A](/accessories/207) | [Heat Sink - Micro Alligator Clip](/accessories/207) | [$12.99](/accessories/207) | [Add to Cart](https://americanbeautytools.com/viewcart/HS-A/1) |
| [HS-B](/accessories/208) | [Heat Sink - Alligator Clip](/accessories/208) | [$12.99](/accessories/208) | [Add to Cart](https://americanbeautytools.com/viewcart/HS-B/1) |
| [HS-C](/accessories/209) | [Heat Sink - Alligator Clip w. Barrel](/accessories/209) | [$12.99](/accessories/209) | [Add to Cart](https://americanbeautytools.com/viewcart/HS-C/1) |
| [SS-8](/accessories/210) | [Solder Sucker (3 oz)](/accessories/210) | [$12.99](/accessories/210) | [Add to Cart](https://americanbeautytools.com/viewcart/SS-8/1) |

  
  

SIMILAR PRODUCTS

  

The following products are related (similar model but different specifications, etc.) to Model 3108-20 featured on this page:  
  

| Model | Product Name | Price |  |
| --- | --- | --- | --- |
| [3108-25](/soldering-iron-3108/2) | [25 Watt, 1/8" Pencil-Style Soldering Iron](/soldering-iron-3108/2) | [$79.99](/soldering-iron-3108/2) | [Add to Cart](https://americanbeautytools.com/viewcart/3108-25/1) |
| [3108-30](/soldering-iron-3108/3) | [30 Watt, 1/8" Pencil-Style Soldering Iron](/soldering-iron-3108/3) | [$79.99](/soldering-iron-3108/3) | [Add to Cart](https://americanbeautytools.com/viewcart/3108-30/1) |
| [A92206](/lightweight-92/41008) | [20 Watt, 1/8" Light-Duty Soldering Iron](/lightweight-92/41008) | [$125.00](/lightweight-92/41008) | [Add to Cart](https://americanbeautytools.com/viewcart/A92206/1) |
| [A92256](/lightweight-92/41009) | [25 Watt, 1/8" Light-Duty Soldering Iron](/lightweight-92/41009) | [$125.00](/lightweight-92/41009) | [Add to Cart](https://americanbeautytools.com/viewcart/A92256/1) |
| [A92306](/lightweight-92/41010) | [30 Watt, 1/8" Light-Duty Soldering Iron](/lightweight-92/41010) | [$125.00](/lightweight-92/41010) | [Add to Cart](https://americanbeautytools.com/viewcart/A92306/1) |
| [A92356](/lightweight-92/41011) | [35 Watt, 1/8" Light-Duty Soldering Iron](/lightweight-92/41011) | [$125.00](/lightweight-92/41011) | [Add to Cart](https://americanbeautytools.com/viewcart/A92356/1) |
| [A92406](/lightweight-92/41012) | [40 Watt, 1/8" Light-Duty Soldering Iron](/lightweight-92/41012) | [$125.00](/lightweight-92/41012) | [Add to Cart](https://americanbeautytools.com/viewcart/A92406/1) |
| [A92456](/lightweight-92/41013) | [45 Watt, 1/8" Light-Duty Soldering Iron](/lightweight-92/41013) | [$125.00](/lightweight-92/41013) | [Add to Cart](https://americanbeautytools.com/viewcart/A92456/1) |
| [A92506](/lightweight-92/41014) | [50 Watt, 1/8" Light-Duty Soldering Iron](/lightweight-92/41014) | [$125.00](/lightweight-92/41014) | [Add to Cart](https://americanbeautytools.com/viewcart/A92506/1) |
| [V36GS3](/stations-and-controllers/96) | [20 Watt Industrial Grade Soldering Station](/stations-and-controllers/96) | [$225.00](/stations-and-controllers/96) | [Add to Cart](https://americanbeautytools.com/viewcart/V36GS3/1) |

  
  

APPLICATIONS

  

Users of this product have stated that they use it for several jobs which include but are not limited to:

1. Melting zinc filler material for cosmetic repairs to soft metal sculptures
2. Soldering daily and high volumes assemblies

  
  

TECHNICAL SPECIFICATIONS

  

|  |  |
| --- | --- |
| Standard Tip Style | Chisel |
| Wattage | 20 watts |
| AMP Draw | < .5 Amp |
| Connection Type | NEMA 5-15P |
| Maximum Temperature | 800 °F / 427°C |
| Stand included? | Yes |
| Available in a 220-240 VAC? | Not currently available in high voltage version |
| Tip Diameter | .125 in |
| Tip Length | 2.25 in / 5.72 cm |
| Product Length | 7.5 in / 19.05 cm |
| Product Width | 1.125 in / 2.86 cm |
| Product Height | 1.125 in / 2.86 cm |
| Product Weight | .55 lbs / 0.25 kg |
| Package Dimensions (Inches) | 12 by 2.25 by 2.25 |
| Package Weight | 1 lbs / 0.45 kg |
| Country of Origin | US |
| Harmonization Code: | 8515.11.0000 |
| Cage Code | 02105 |
| NSN # | 3439-01-103-0243 |
| RoHS Compliant | Yes |
| BS EN IEC 60335-1:2023+A11:2023 | Yes |
| BS EN 60335-2-45:2002+A11:2023 | Yes |
| WEEE Compliant | Yes |
| CE Certified | Yes |
| Understanding Tip Measurements | [Explanation](https://www.americanbeautytools.com/bulletin/17) |
| Warranty Policy | [Details](https://www.americanbeautytools.com/warranty) |
| User Manual | [User Manual](https://www.americanbeautytools.com/downloads/AmericanBeautySolderingIronManual.pdf) |

[![](https://americanbeautytools.com/images/nav/certificate.png) C of C](/app/certificates/Certificate_of_Compliance_Origin_3108-20_12126083954.pdf)

[![](https://americanbeautytools.com/images/nav/CELogoTiny.png)](/app/certificates/EU_Declaration_of_Conformity_3108-20_12126083954.pdf)

[![](https://americanbeautytools.com/images/nav/ukca.jpg)](/app/certificates/UKCA_Declaration_of_Conformity_3108-20_12126083954.pdf)

[![](https://americanbeautytools.com/images/nav/manual.png) User Manual](https://www.americanbeautytools.com/downloads/AmericanBeautySolderingIronManual.pdf)

[![](https://americanbeautytools.com/images/nav/pdf.png) Product Data Sheet](/app/datasheets/Model_3108-20_12126083953.pdf)

**American Beauty Soldering Tools**

Need Help? Bored? Call **[1-800-550-2510](tel:18005502510)**

[![Watch our soldering videos!](https://americanbeautytools.com/images/nav/social/social_you_tube.png)](http://www.youtube.com/SolderingGuru)

[![Become a fan on Facebook!](https://americanbeautytools.com/images/nav/social/social_facebook.png)](https://www.facebook.com/soldering.irons)

[![Follow American Beauty Tools!](https://americanbeautytools.com/images/nav/social/social_twitter.png)](http://twitter.com/SolderingGuru)

[Sitemap](https://americanbeautytools.com/sitemap.txt)

2026 American Beauty Tools

[Legal notice](https://americanbeautytools.com/legal)

[Privacy policy](https://americanbeautytools.com/privacy)

[Design by Windy Hill Web Solutions](http://www.windyhillwebs.com)