American Beauty Tools



[![Product Category Image](https://americanbeautytools.com/images/landing_images/SPOOLS_812017072708.jpg)](https://americanbeautytools.com/Soldering-Irons/38)

[![Product Category Image](https://americanbeautytools.com/images/landing_images/Stained Glass_812017073009.jpg)](https://americanbeautytools.com/Soldering-Irons/14)

[![Product Category Image](https://americanbeautytools.com/images/landing_images/300 Watt_812017071823.jpg)](https://americanbeautytools.com/Soldering-Irons/18)

[![Product Category Image](https://americanbeautytools.com/images/landing_images/Pencil Iron_60 Watt_812017073337.jpg)](https://americanbeautytools.com/v2/soldering-iron-3112)

![Product Category Image](https://americanbeautytools.com/images/landing_images/soldering-irons_a_1092024022510.jpeg)

Esico Triton & American Beauty
------------------------------

The only Choices for Heavy-duty
-------------------------------

American Beauty & Esico Triton heavy-duty soldering irons are ideal for big soldering jobs and production-line environments. The most common reason for substandard solder joints stems from soldering irons with insufficient heat to transfer into the joint. Our irons were created with the sole purpose to deliver heat...lots and lots of heat.  We've been building these quality tools in the Metro Detroit area since 1894 and have developed quite a following in that time.  We offer a full range of sizes and wattages to tackle just about any job out there.  However, if you're just looking for a cheap import iron to finish off your kid's model airplane, that's fine...but you've reached the wrong website. If you've come looking for a tool that's going to offer unparalleled heat & performance you've come to the right place.

We challenge you to find a *tougher* soldering iron on the market today. Scroll down this page to see a wide range of our irons.  And, as always, please feel free to contact us directly to discuss your job prior to purchasing to make sure you're getting just the right tool.

*\*\* Unless otherwise stated in Product Name, all American Beauty items are wired for Low Voltage Current (110-120 VAC) with North American Cordsets (Nema 5-15). \*\**

Categories
----------

[Pencil Irons](https://americanbeautytools.com/pencil-irons)

[Lightweight Irons](https://americanbeautytools.com/lightweight-irons)

[Heavy-Duty Irons](https://americanbeautytools.com/heavy-duty-irons)

[Ergo Irons](https://americanbeautytools.com/ergo-irons)

[Soldering Kits](https://americanbeautytools.com/solder-kits)

[Soldering Stations](https://americanbeautytools.com/stations-and-controllers)

[Soldering Tips](https://americanbeautytools.com/soldering-tips)

> Your soldering irons are the best. I've used my old trusty, rusty's for about 40 years, since I bought them all at Chicago's historic Maxwell street market for about 5 bucks as a young, broke artist. They sure have served me well all these years..soldering many a [lamp](http://www.opalglassstudio.com/lighting.html) and [window](http://www.opalglassstudio.com/commercial.html)!
>
> I also think its great you encourage [repair of tools](https://www.americanbeautytools.com/repair) in this sadly throw away world. Thanks for your doing your part of keeping less of landfills.
>
> Sharon B. @ [Opal Glass Studio](http://www.opalglassstudio.com/) in Chicago, IL

> My company specializes in supplying and installing high-end custom copper gutter-work, and I've been using American Beauty's [300](https://www.americanbeautytools.com/images/charlie-3a.jpg) & [550 watt](https://www.americanbeautytools.com/images/charlie-4a.jpg) heavy-duty soldering irons for years. It is absolutely essential that these joints are done properly the first time, as repairs will prove 100 times more difficult than simply doing the job correctly the first time. I can always count on my American Beauty iron to generate and maintain enough heat to ensure perfectly soldered seams.
>
> [Charlie @ Chuck-Ways Contracting Co., Shelby Township, MI](https://www.americanbeautytools.com/index.php?req=sheet&app=1)

**American Beauty Soldering Tools**

Need Help? Bored? Call **[1-800-550-2510](tel:18005502510)**

[![Watch our soldering videos!](https://americanbeautytools.com/images/nav/social/social_you_tube.png)](http://www.youtube.com/SolderingGuru)

[![Become a fan on Facebook!](https://americanbeautytools.com/images/nav/social/social_facebook.png)](https://www.facebook.com/soldering.irons)

[![Follow American Beauty Tools!](https://americanbeautytools.com/images/nav/social/social_twitter.png)](http://twitter.com/SolderingGuru)

[Sitemap](https://americanbeautytools.com/sitemap.txt)

2026 American Beauty Tools

[Legal notice](https://americanbeautytools.com/legal)

[Privacy policy](https://americanbeautytools.com/privacy)

[Design by Windy Hill Web Solutions](http://www.windyhillwebs.com)