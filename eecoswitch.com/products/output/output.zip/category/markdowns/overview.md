## Category

[![EECO Switch](http://www.eecoswitch.com/wp-content/uploads/2012/03/eeco_logo.png)](http://www.eecoswitch.com "EECO Switch")

Call Us Toll Free: (800) 854-3808

* [Home](http://www.eecoswitch.com/index.php)
* [About](http://www.eecoswitch.com/our-companies/)
+ [Our Companies](http://www.eecoswitch.com/our-companies/)
+ [Partners](http://www.eecoswitch.com/about-us/partners/)
* [Products](http://www.eecoswitch.com/products/)
+ [Electromechanical Switches](http://www.eecoswitch.com/product/electromechanical-switches/)
- [MICRO-DIP®](http://www.eecoswitch.com/products/micro-dip/)
- [STRIPSWITCH®](http://www.eecoswitch.com/products/stripswitch/)
- [Thumbwheel Switches](http://www.eecoswitch.com/products/thumbwheel-switches/)
+ [Elastomer Keypads](http://www.eecoswitch.com/product/elastomeric-keypads/)
+ [Custom Membrane Switches](http://www.eecoswitch.com/product/custom-membrane-switches/)
* [Compliance](http://www.eecoswitch.com/compliance/)
* [Distributors](http://www.eecoswitch.com/distributors/)
* [Contact Us](http://www.eecoswitch.com/contact-us/)
+ [Request a Quote](http://www.eecoswitch.com/contact-us/request-a-quote/)
* [EECO International](http://eecoswitch.co.uk)

## Electromechanical Switches

[Home](http://www.eecoswitch.com "EECO Switch") \ [Products](http://www.eecoswitch.com/products/ "Products") \ [Electromechanical Switches](http://www.eecoswitch.com/product/electromechanical-switches/ "Electromechanical Switches")

Product Categories

![](http://www.eecoswitch.com/wp-content/themes/main/images/categories_top.png)

Product Categories

* [Custom Membrane Switches](http://www.eecoswitch.com/products/custom-membrane-switches/)
* [Elastomeric Keypads](http://www.eecoswitch.com/products/elastomeric-keypads/)
* [Electromechanical Switches](http://www.eecoswitch.com/products/electromechanical-switches/)
+ [Micro-Dip®](http://www.eecoswitch.com/products/micro-dip/)
+ [StripSwitch®](http://www.eecoswitch.com/products/stripswitch/)
+ [Thumbwheel Switches](http://www.eecoswitch.com/products/thumbwheel-switches/)

![](http://www.eecoswitch.com/wp-content/themes/main/images/categories_bottom.png)

|  |  |  |
| --- | --- | --- |
| [**MICRO-DIP®**](http://www.eecoswitch.com/products/micro-dip/) | [**STRIPSWITCH®**](http://www.eecoswitch.com/products/stripswitch/) | [**Thumbwheel Series**](http://www.eecoswitch.com/products/thumbwheel-switches/) |

EECO’s experience in and product range of electromechanical, coded switches is extensive. For example, in 1963, EECO pioneered the first lighted thumbwheel switch, and then continued to develop broad offerings of thumbwheels for industrial and military applications.

> EECO is recognized as the world leader in thumbwheel switches and as a global leader in binary-coded and printed-circuit-board-mounted, coded switches.

### Micro Dip® Rotary Switches

An EECO innovation, our sealed [MICRO-Dip®](http://www.eecoswitch.com/products/micro-dip/) rotary switches permit direct setting of binary coded values for PROMS and other addressable devices.

Our Micro-Dip switch materials were selected to withstand high surface-mount process temperatures and are engineered into a low profile, fully sealed package.

The **[2300 Series](http://www.eecoswitch.com/product/2300-series/)** also includes the industry’s only double-pole rotary DIP switch.

### Rotary Coded StripSwitch

Invented by EECO, the 2100 series [Stripswitch®](http://www.eecoswitch.com/products/stripswitch/) is a PC-board-mounted thumbwheel switch that features direct binary conversion in a compact package. It may be ordered in assemblies of one to four switches on a single terminal board.

The **[2700 Series](http://www.eecoswitch.com/product/2700-series/)** is fully sealed for wave soldering and automatic cleaning processes. Options include extended shafts, black or white rotors, and a wide variety of coded outputs. Legends are located on both top and side of the thumbwheel for maximum flexibility.

### Thumbwheel Switches

EECO’s **[1776 and 1976 Thumbwheels](http://www.eecoswitch.com/product/17761976-series/)** are the standards of the industry.
Both series offer 8, 10, 12, or 16 position binary or decimal codes for all possible applications.

The **[2000 Series](http://www.eecoswitch.com/product/2000-series/)** is ideal for harsh industrial use since the large size of the switch makes it easy to set even when wearing gloves.

The **[7000 Series](http://www.eecoswitch.com/product/7000-series/)** features heavy-duty construction, sealed housings, and is designed to meet the strictest of military performance requirements.

Our [1000](http://www.eecoswitch.com/product/1000-series/) , [1100](http://www.eecoswitch.com/product/1100-series/) and [1400](http://www.eecoswitch.com/product/1400-series/) series offer either thumbwheel or push-wheel actuation in an ultra-compact package for space-sensitive applications.

[![](http://www.eecoswitch.com/wp-content/uploads/2011/08/Electromechanical-Switches-285x200.jpg)](http://www.eecoswitch.com/wp-content/uploads/2011/08/Electromechanical-Switches.jpg)

[Get More Info](http://www.eecoswitch.com/contact-us/)

> EECO is a leading supplier of digital switches, elastomer keypads, and membrane keypads and assemblies. Major markets for the company’s products include medical equipment, industrial controls, and aircraft entertainment systems.

Copyright © 2011 EECO Switch

* [About Us](http://www.eecoswitch.com/our-companies/)
* [Products](http://www.eecoswitch.com/products/)
* [Compliance](http://www.eecoswitch.com/compliance/)
* [EECO International](http://eecoswitch.co.uk/)
* [Contact Us](http://www.eecoswitch.com/contact-us/)


