## Category

[![EECO Switch](http://www.eecoswitch.com/wp-content/uploads/2012/03/eeco_logo.png)](http://www.eecoswitch.com "EECO Switch")

Call Us Toll Free: (800) 854-3808

* [Home](http://www.eecoswitch.com/index.php)
* [About](http://www.eecoswitch.com/our-companies/)
+ [Our Companies](http://www.eecoswitch.com/our-companies/)
+ [Partners](http://www.eecoswitch.com/about-us/partners/)
* [Products](http://www.eecoswitch.com/products/)
+ [Electromechanical Switches](http://www.eecoswitch.com/product/electromechanical-switches/)
- [MICRO-DIP®](http://www.eecoswitch.com/products/micro-dip/)
- [STRIPSWITCH®](http://www.eecoswitch.com/products/stripswitch/)
- [Thumbwheel Switches](http://www.eecoswitch.com/products/thumbwheel-switches/)
+ [Elastomer Keypads](http://www.eecoswitch.com/product/elastomeric-keypads/)
+ [Custom Membrane Switches](http://www.eecoswitch.com/product/custom-membrane-switches/)
* [Compliance](http://www.eecoswitch.com/compliance/)
* [Distributors](http://www.eecoswitch.com/distributors/)
* [Contact Us](http://www.eecoswitch.com/contact-us/)
+ [Request a Quote](http://www.eecoswitch.com/contact-us/request-a-quote/)
* [EECO International](http://eecoswitch.co.uk)

## 2300 Series

[Home](http://www.eecoswitch.com "EECO Switch") \ [Products](http://www.eecoswitch.com/products/ "Products") \ [Electromechanical Switches](http://www.eecoswitch.com/products/electromechanical-switches/ "Electromechanical Switches") \ [Micro-Dip®](http://www.eecoswitch.com/products/micro-dip/ "Micro-Dip®") \ [2300 Series](http://www.eecoswitch.com/product/2300-series/ "2300 Series")

Product Categories

![](http://www.eecoswitch.com/wp-content/themes/main/images/categories_top.png)

Product Categories

* [Custom Membrane Switches](http://www.eecoswitch.com/products/custom-membrane-switches/)
* [Elastomeric Keypads](http://www.eecoswitch.com/products/elastomeric-keypads/)
* [Electromechanical Switches](http://www.eecoswitch.com/products/electromechanical-switches/)
+ [Micro-Dip®](http://www.eecoswitch.com/products/micro-dip/)
+ [StripSwitch®](http://www.eecoswitch.com/products/stripswitch/)
+ [Thumbwheel Switches](http://www.eecoswitch.com/products/thumbwheel-switches/)

![](http://www.eecoswitch.com/wp-content/themes/main/images/categories_bottom.png)

* [General Details](#)
* [Specifications](#)

An EECO innovation, the 2300 series MICRO-DIP® family includes the industry's only double pole rotary DIP switch.

Ideal for CMOS logic applications, the 2300 series double pole switch offers a unique output arrangement in which all four outputs bits are always connected to one of two independent commons. This allows the use of a single pull-up resistor instead of four, as would be required by a conventional DIP switch.

The 2300 series includes 10 and 16 position double pole models, and a 10 position right angle version. The double pole switches are available with optional process seals for wave soldering, and all are color coded for easy identification.

The 2300 series is series is covered by EECO's EXCLUSIVE LIFETIME WARRANTY.

![](http://www.eecoswitch.com/wp-content/uploads/2011/08/2300_specs.png)

[![](http://www.eecoswitch.com/wp-content/uploads/2011/08/2300-final-285x200.gif)](http://www.eecoswitch.com/wp-content/uploads/2011/08/2300-final.gif)

[Get More Info](http://www.eecoswitch.com/contact-us/)

* [![Download PDF File](http://www.eecoswitch.com/wp-content/themes/main/images/assets/icons/File_Pdf.png)](http://www.eecoswitch.com/wp-content/uploads/2011/08/2300.pdf)

> EECO is a leading supplier of digital switches, elastomer keypads, and membrane keypads and assemblies. Major markets for the company’s products include medical equipment, industrial controls, and aircraft entertainment systems.

Copyright © 2011 EECO Switch

* [About Us](http://www.eecoswitch.com/our-companies/)
* [Products](http://www.eecoswitch.com/products/)
* [Compliance](http://www.eecoswitch.com/compliance/)
* [EECO International](http://eecoswitch.co.uk/)
* [Contact Us](http://www.eecoswitch.com/contact-us/)


